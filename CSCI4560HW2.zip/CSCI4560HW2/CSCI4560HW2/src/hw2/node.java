package hw2;

public class node {
	
 public int x = 0;
 public int y = 0;
 
 node()
 {
	 x = 0;
	 y = 1;
 }
		 
}
